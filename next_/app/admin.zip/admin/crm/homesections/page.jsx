"use client";
import React, { useState } from 'react';
import '../../css/custom.css';
import AdminModal from '@/components/admin/AdminModal';

const HomeSections = () => {
    const [sections, setSections] = useState([
        { id: 1, name: 'Featured Products', type: 'products', order: 1, status: true },
        { id: 2, name: 'Collections Showcase', type: 'categories', order: 2, status: true },
        { id: 3, name: 'Customer Reviews', type: 'testimonials', order: 3, status: false },
        { id: 4, name: 'Newsletter Banner', type: 'custom', order: 4, status: true },
    ]);

    const [showModal, setShowModal] = useState(false);
    const [formData, setFormData] = useState({ name: '', type: 'products', order: 1, status: true });

    const handleAdd = () => {
        setFormData({ name: '', type: 'products', order: (sections.length + 1), status: true });
        setShowModal(true);
    };

    const handleEdit = (section) => {
        setFormData(section);
        setShowModal(true);
    };

    const handleSave = () => {
        if (!formData.name) return;
        if (formData.id) {
            setSections(sections.map(s => s.id === formData.id ? formData : s));
        } else {
            setSections([...sections, { ...formData, id: Date.now() }]);
        }
        setShowModal(false);
    };

    return (
        <div className="space-y-6">
            <div className="page-header">
                <div>
                    <h2>Home Page Sections</h2>
                    <p>Manage the structure and layout of the homepage</p>
                </div>
                <button className="btn-primary" onClick={handleAdd}>
                    <i className="fas fa-plus mr-2"></i>Add Section
                </button>
            </div>

            <div className="admin-card">
                <div className="admin-card-header"><h3>All Sections</h3></div>
                <div style={{ overflowX: 'auto' }}>
                    <table className="admin-table">
                        <thead>
                            <tr><th>Section Name</th><th>Type</th><th style={{ textAlign: 'center' }}>Order</th><th style={{ textAlign: 'center' }}>Status</th><th style={{ textAlign: 'right' }}>Actions</th></tr>
                        </thead>
                        <tbody>
                            {sections.sort((a,b) => a.order - b.order).map((s) => (
                                <tr key={s.id}>
                                    <td className="cell-primary">{s.name}</td>
                                    <td><span className="cell-mono" style={{ textTransform: 'capitalize' }}>{s.type}</span></td>
                                    <td style={{ textAlign: 'center' }}>
                                        <span style={{ display: 'inline-flex', alignItems: 'center', justifyContent: 'center', width: 28, height: 28, borderRadius: 6, background: '#f8fafc', border: '1px solid #e2e8f0', fontWeight: 700, fontSize: 13, color: '#475569' }}>{s.order}</span>
                                    </td>
                                    <td style={{ textAlign: 'center' }}><span className={`status-pill ${s.status ? 'pill-active' : 'pill-inactive'}`}>{s.status ? 'Active' : 'Hidden'}</span></td>
                                    <td style={{ textAlign: 'right' }}>
                                        <div style={{ display: 'flex', gap: 6, justifyContent: 'flex-end' }}>
                                            <button className="btn-icon btn-icon-edit" onClick={() => handleEdit(s)}><i className="fas fa-edit"></i></button>
                                            <button className="btn-icon btn-icon-delete"><i className="fas fa-trash-alt"></i></button>
                                        </div>
                                    </td>
                                </tr>
                            ))}
                        </tbody>
                    </table>
                </div>
            </div>

            <AdminModal
                isOpen={showModal}
                onClose={() => setShowModal(false)}
                title={formData.id ? "Edit Section" : "Add New Section"}
                footer={
                    <>
                        <button className="btn-secondary" onClick={() => setShowModal(false)}>Cancel</button>
                        <button className="btn-primary" onClick={handleSave}>Save Section</button>
                    </>
                }
            >
                <div className="space-y-4">
                    <div className="form-group">
                        <label>Section Display Name</label>
                        <input 
                            type="text" 
                            className="form-control" 
                            value={formData.name} 
                            onChange={e => setFormData({...formData, name: e.target.value})}
                            placeholder="e.g. New Seasonal Arrivals"
                        />
                    </div>
                    <div className="form-group">
                        <label>Content Type</label>
                        <select 
                            className="form-control"
                            value={formData.type}
                            onChange={e => setFormData({...formData, type: e.target.value})}
                        >
                            <option value="products">Products Grid</option>
                            <option value="categories">Categories Showcase</option>
                            <option value="testimonials">Testimonials / Reviews</option>
                            <option value="custom">Custom Banner / Newsletter</option>
                            <option value="video">Promotional Video</option>
                        </select>
                    </div>
                    <div className="form-group">
                        <label>Display Order</label>
                        <input 
                            type="number" 
                            className="form-control" 
                            value={formData.order} 
                            onChange={e => setFormData({...formData, order: parseInt(e.target.value)})}
                        />
                    </div>
                    <div className="form-group">
                        <label>Status</label>
                        <select 
                            className="form-control"
                            value={formData.status.toString()}
                            onChange={e => setFormData({...formData, status: e.target.value === 'true'})}
                        >
                            <option value="true">Visible</option>
                            <option value="false">Hidden</option>
                        </select>
                    </div>
                </div>
            </AdminModal>
        </div>
    );
};

export default HomeSections;
