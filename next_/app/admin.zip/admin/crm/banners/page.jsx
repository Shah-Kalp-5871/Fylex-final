"use client";
import React, { useState, useRef, useEffect } from 'react';
import { TabulatorFull as Tabulator } from 'tabulator-tables';
import 'tabulator-tables/dist/css/tabulator.min.css';
import '@/app/admin/css/datatable.css';
import '@/app/admin/css/custom.css';
import AdminModal from '@/components/admin/AdminModal';

const BannerList = () => {
    const [banners, setBanners] = useState([
        { id: 1, title: 'Summer Collection', position: 'Hero', status: 'active', image: 'summer-collection.jpg', created_at: '2024-03-10' },
        { id: 2, title: 'New Arrivals', position: 'Below Hero', status: 'active', image: 'new-arrivals.jpg', created_at: '2024-03-05' },
        { id: 3, title: 'Sale Banner', position: 'Footer', status: 'inactive', image: 'sale-banner.jpg', created_at: '2024-02-28' },
    ]);

    const [showModal, setShowModal] = useState(false);
    const [formData, setFormData] = useState({ title: '', position: 'Hero', status: 'active' });
    const tableRef = useRef(null);
    const [table, setTable] = useState(null);

    const actionsRef = useRef({ setBanners, setFormData, setShowModal });
    useEffect(() => { actionsRef.current = { setBanners, setFormData, setShowModal }; }, [banners]);

    useEffect(() => {
        if (tableRef.current) {
            const tabulator = new Tabulator(tableRef.current, {
                data: banners,
                layout: "fitDataFill",
                responsiveLayout: false,
                pagination: "local",
                paginationSize: 10,
                columns: [
                    {
                        title: "BANNER", field: "title", width: 340,
                        formatter: (cell) => {
                            const d = cell.getRow().getData();
                            return `
                                <div style="display:flex;align-items:center;gap:14px;padding:4px 0">
                                    <div style="width:56px;height:36px;background:#f8fafc;border:1px solid #e2e8f0;border-radius:8px;display:flex;align-items:center;justify-content:center;flex-shrink:0">
                                        <i class="fas fa-image" style="color:#94a3b8;font-size:12px"></i>
                                    </div>
                                    <div style="display:flex;flex-direction:column;gap:1px">
                                        <div style="font-weight:700;color:#1e293b;font-size:14px">${d.title}</div>
                                        <div style="font-size:11px;color:#94a3b8;font-weight:600">Created: ${d.created_at}</div>
                                    </div>
                                </div>
                            `;
                        }
                    },
                    {
                        title: "POSITION", field: "position", width: 150,
                        formatter: (cell) => `<span style="font-size:11px;font-weight:700;color:#64748b;background:#f8fafc;padding:4px 12px;border-radius:8px;border:1px solid #e2e8f0;text-transform:uppercase;letter-spacing:0.03em">${cell.getValue()}</span>`
                    },
                    {
                        title: "STATUS", field: "status", width: 120, hozAlign: "center",
                        formatter: (cell) => {
                            const v = cell.getValue();
                            return `<span class="status-pill ${v === 'active' ? 'pill-info' : 'pill-inactive'}" style="border-radius:8px;padding:4px 12px">${v?.toUpperCase()}</span>`;
                        }
                    },
                    {
                        title: "ACTIONS", headerSort: false, hozAlign: "right", width: 120,
                        formatter: () => `
                            <div style="display:flex;gap:12px;justify-content:flex-end">
                                <button class="btn-icon-edit" style="background:transparent;border:none;color:#94a3b8;cursor:pointer;font-size:16px"><i class="fas fa-edit"></i></button>
                                <button class="btn-icon-delete" style="background:transparent;border:none;color:#94a3b8;cursor:pointer;font-size:16px"><i class="fas fa-trash-alt"></i></button>
                            </div>
                        `,
                        cellClick: (e, cell) => {
                            const d = cell.getRow().getData();
                            if (e.target.closest('.btn-icon-edit')) {
                                actionsRef.current.setFormData(d);
                                actionsRef.current.setShowModal(true);
                            }
                            if (e.target.closest('.btn-icon-delete')) {
                                if (window.confirm('Delete this banner?')) {
                                    actionsRef.current.setBanners(prev => prev.filter(b => b.id !== d.id));
                                }
                            }
                        }
                    }
                ],
            });
            setTable(tabulator);
        }
    }, []);

    useEffect(() => {
        if (table) table.replaceData(banners);
    }, [banners, table]);

    const handleAdd = () => {
        setFormData({ title: '', position: 'Hero', status: 'active' });
        setShowModal(true);
    };

    const handleSave = () => {
        if (!formData.title) return;
        if (formData.id) {
            setBanners(banners.map(b => b.id === formData.id ? formData : b));
        } else {
            setBanners([...banners, { ...formData, id: Date.now(), created_at: new Date().toISOString().split('T')[0] }]);
        }
        setShowModal(false);
    };

    return (
        <div className="space-y-6 animate-fade-in">
            <div className="page-header" style={{ alignItems: 'flex-start', marginBottom: 32 }}>
                <div>
                    <h2 style={{ fontSize: 26, fontWeight: 800, color: '#1e293b', letterSpacing: '-0.02em' }}>Sliders & Banners</h2>
                    <p style={{ color: '#64748b', fontSize: 14, marginTop: 4, fontWeight: 500 }}>Manage homepage sliders and promotional campaign assets</p>
                </div>
                <button className="btn-indigo-gradient" onClick={handleAdd}>
                    <i className="fas fa-plus mr-2" style={{ fontSize: 12 }}></i>Add Banner
                </button>
            </div>

            <div className="admin-card" style={{ padding: '20px 24px', borderRadius: 16 }}>
                <div style={{ display: 'flex', gap: 16, alignItems: 'center', flexWrap: 'wrap' }}>
                    <div className="admin-search" style={{ flex: 2, minWidth: 300 }}>
                        <i className="fas fa-search" style={{ color: '#94a3b8' }}></i>
                        <input 
                            type="text" 
                            placeholder="Search by title, position..." 
                            style={{ background: '#f8fafc', borderRadius: 10, border: '1px solid #e2e8f0', padding: '11px 16px 11px 42px' }} 
                        />
                    </div>
                    <div style={{ flex: 1, minWidth: 200 }}>
                        <select style={{ width: '100%', padding: '11px 16px', border: '1px solid #e2e8f0', borderRadius: 10, background: '#fff', color: '#4b5a7a', fontSize: 13, fontWeight: 600, outline: 'none', cursor: 'pointer' }}>
                            <option>All Positions</option>
                            <option>Hero</option>
                            <option>Below Hero</option>
                            <option>Footer</option>
                        </select>
                    </div>
                    <button className="btn-filter-dark">
                        <i className="fas fa-filter mr-2"></i> Filter
                    </button>
                </div>
            </div>

            <div className="admin-card" style={{ borderRadius: 16, overflow: 'hidden', border: '1px solid #e2e8f0' }}>
                <div style={{ overflowX: 'auto', padding: '0 8px 8px' }}>
                    <div style={{ minWidth: 900 }}>
                        <div ref={tableRef}></div>
                    </div>
                </div>
            </div>

            <AdminModal
                isOpen={showModal}
                onClose={() => setShowModal(false)}
                title={formData.id ? "Edit Banner" : "Add New Banner"}
                footer={
                    <>
                        <button className="btn-secondary" onClick={() => setShowModal(false)}>Cancel</button>
                        <button className="btn-primary" onClick={handleSave}>Save Banner</button>
                    </>
                }
            >
                <div className="space-y-4">
                    <div className="form-group">
                        <label>Banner Title</label>
                        <input 
                            type="text" 
                            className="form-control" 
                            value={formData.title} 
                            onChange={e => setFormData({...formData, title: e.target.value})}
                            placeholder="e.g. Summer Collection 2024"
                        />
                    </div>
                    <div className="form-group">
                        <label>Position</label>
                        <select 
                            className="form-control"
                            value={formData.position}
                            onChange={e => setFormData({...formData, position: e.target.value})}
                        >
                            <option>Hero</option>
                            <option>Below Hero</option>
                            <option>Footer</option>
                            <option>Sidebar</option>
                        </select>
                    </div>
                    <div className="form-group">
                        <label>Status</label>
                        <select 
                            className="form-control"
                            value={formData.status}
                            onChange={e => setFormData({...formData, status: e.target.value})}
                        >
                            <option value="active">Active</option>
                            <option value="inactive">Inactive</option>
                        </select>
                    </div>
                    <div className="form-group">
                        <label>Banner Image</label>
                        <div style={{ padding: '20px', border: '2px dashed #e2e8f0', borderRadius: 12, textAlign: 'center', background: '#f8fafc' }}>
                            <i className="fas fa-cloud-upload-alt" style={{ fontSize: 24, color: '#94a3b8', marginBottom: 8 }}></i>
                            <div style={{ fontSize: 13, color: '#64748b' }}>Click or drag image to upload</div>
                            <div style={{ fontSize: 11, color: '#94a3b8', marginTop: 4 }}>Recommended size: 1920x600px</div>
                        </div>
                    </div>
                </div>
            </AdminModal>
        </div>
    );
};

export default BannerList;
