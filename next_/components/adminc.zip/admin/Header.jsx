"use client";
import { usePathname } from 'next/navigation';
import React, { useState, useEffect } from 'react';
import Link from 'next/link';

const Header = ({ setMobileOpen }) => {
  const pathname = usePathname();
  const [timeLeft, setTimeLeft] = useState(120 * 60);
  const [dropdownOpen, setDropdownOpen] = useState(false);

  useEffect(() => {
    const timer = setInterval(() => {
      setTimeLeft(prev => (prev > 0 ? prev - 1 : 0));
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  const formatTime = (seconds) => {
    const h = Math.floor(seconds / 3600);
    const m = Math.floor((seconds % 3600) / 60);
    const s = seconds % 60;
    return `${h.toString().padStart(2, '0')}:${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`;
  };

  const getPageTitle = () => {
    const path = pathname.split('/').filter(Boolean);
    const segment = path[path.length - 1] || 'dashboard';
    return segment.replace(/-/g, ' ');
  };

  return (
    <header className="admin-header">
      <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
        <button onClick={() => setMobileOpen(true)}
                className="hamburger-btn"
                style={{ width: 36, height: 36, borderRadius: 8, border: '1px solid #e2e8f0', background: '#fff', cursor: 'pointer', color: '#64748b' }}>
          <i className="fas fa-bars"></i>
        </button>
        <div className="header-title">
          <h1>{getPageTitle()}</h1>
          <div className="header-breadcrumb">
            <span style={{ display: 'inline-block', width: 5, height: 5, borderRadius: '50%', background: '#6366f1', marginRight: 6, verticalAlign: 'middle' }}></span>
            Admin / {getPageTitle()}
          </div>
        </div>
      </div>

      <div style={{ display: 'flex', alignItems: 'center', gap: 16 }}>
        {/* Session Timer */}
        <div className="hidden sm:flex" style={{ alignItems: 'center', gap: 10, background: '#f8fafc', padding: '6px 14px', borderRadius: 10, border: '1px solid #e2e8f0' }}>
          <i className="fas fa-clock" style={{ color: '#ef4444', fontSize: 12 }}></i>
          <div>
            <div style={{ fontSize: 10, fontWeight: 700, color: '#94a3b8', textTransform: 'uppercase', letterSpacing: '0.05em', lineHeight: 1 }}>Session</div>
            <div style={{ fontSize: 13, fontWeight: 700, color: '#1e293b', fontFamily: "'SF Mono', monospace", letterSpacing: '-0.02em' }}>{formatTime(timeLeft)}</div>
          </div>
        </div>

        {/* Profile */}
        <div style={{ position: 'relative' }}>
          <button onClick={() => setDropdownOpen(!dropdownOpen)}
                  style={{ display: 'flex', alignItems: 'center', gap: 10, padding: '4px 8px 4px 4px', borderRadius: 10, border: 'none', background: 'transparent', cursor: 'pointer', transition: 'background 0.15s' }}>
            <div style={{ width: 34, height: 34, background: 'linear-gradient(135deg, #6366f1, #8b5cf6)', borderRadius: 8, display: 'flex', alignItems: 'center', justifyContent: 'center', color: '#fff', fontWeight: 700, fontSize: 13 }}>A</div>
            <div className="hidden md:block" style={{ textAlign: 'left' }}>
              <div style={{ fontSize: 13, fontWeight: 700, color: '#1e293b', lineHeight: 1.2 }}>Admin User</div>
              <div style={{ fontSize: 10, fontWeight: 600, color: '#94a3b8', textTransform: 'uppercase', letterSpacing: '0.04em' }}>Super Admin</div>
            </div>
            <i className="fas fa-chevron-down hidden md:block" style={{ fontSize: 9, color: '#94a3b8', transform: dropdownOpen ? 'rotate(180deg)' : 'none', transition: 'transform 0.2s' }}></i>
          </button>

          {dropdownOpen && (
            <>
              <div style={{ position: 'fixed', inset: 0, zIndex: 40 }} onClick={() => setDropdownOpen(false)}></div>
              <div className="animate-fade-in" style={{ position: 'absolute', right: 0, top: 'calc(100% + 8px)', width: 220, background: '#fff', borderRadius: 12, boxShadow: '0 10px 40px rgba(0,0,0,0.12)', border: '1px solid #e2e8f0', padding: '6px', zIndex: 50 }}>
                <div style={{ padding: '8px 12px', marginBottom: 4 }}>
                  <div style={{ fontSize: 10, fontWeight: 700, color: '#94a3b8', textTransform: 'uppercase', letterSpacing: '0.06em' }}>Account</div>
                </div>
                <Link href="/admin/settings" onClick={() => setDropdownOpen(false)}
                      style={{ display: 'flex', alignItems: 'center', gap: 10, padding: '8px 12px', borderRadius: 8, color: '#475569', textDecoration: 'none', fontSize: 13, fontWeight: 500, transition: 'background 0.15s' }}
                      className="hover:bg-slate-50">
                  <i className="fas fa-user-circle" style={{ width: 16, textAlign: 'center', fontSize: 14 }}></i>
                  My Profile
                </Link>
                <Link href="/admin/settings" onClick={() => setDropdownOpen(false)}
                      style={{ display: 'flex', alignItems: 'center', gap: 10, padding: '8px 12px', borderRadius: 8, color: '#475569', textDecoration: 'none', fontSize: 13, fontWeight: 500, transition: 'background 0.15s' }}
                      className="hover:bg-slate-50">
                  <i className="fas fa-cog" style={{ width: 16, textAlign: 'center', fontSize: 14 }}></i>
                  Settings
                </Link>
                <div style={{ margin: '4px 12px', borderTop: '1px solid #f1f5f9' }}></div>
                <button style={{ display: 'flex', alignItems: 'center', gap: 10, padding: '8px 12px', borderRadius: 8, color: '#ef4444', width: '100%', border: 'none', background: 'none', cursor: 'pointer', fontSize: 13, fontWeight: 600, transition: 'background 0.15s' }}
                        className="hover:bg-red-50"
                        onClick={() => setDropdownOpen(false)}>
                  <i className="fas fa-power-off" style={{ width: 16, textAlign: 'center', fontSize: 14 }}></i>
                  Sign Out
                </button>
              </div>
            </>
          )}
        </div>
      </div>
    </header>
  );
};

export default Header;
