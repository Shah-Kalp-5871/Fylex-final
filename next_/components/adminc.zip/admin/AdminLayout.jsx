"use client";
import React, { useState, useEffect } from 'react';

import Sidebar from './Sidebar';
import Header from './Header';
// Move this import to layout.tsx instead

const AdminLayout = ({ children }) => {
  const [mobileOpen, setMobileOpen] = useState(false);
  const [sidebarExpanded, setSidebarExpanded] = useState(() => {
    return localStorage.getItem('sidebarState') !== 'collapsed';
  });

  useEffect(() => {
    localStorage.setItem('sidebarState', sidebarExpanded ? 'expanded' : 'collapsed');
  }, [sidebarExpanded]);

  return (
    <div className={`admin-root ${sidebarExpanded ? 'sidebar-open' : ''}`}>
      <Sidebar
        mobileOpen={mobileOpen}
        setMobileOpen={setMobileOpen}
        isExpanded={sidebarExpanded}
        setIsExpanded={setSidebarExpanded}
      />

      {/* Mobile Sidebar Overlay */}
      <div className={`sidebar-overlay ${mobileOpen ? 'show' : ''}`}
           onClick={() => setMobileOpen(false)}></div>

      <div className="admin-main">
        <Header setMobileOpen={setMobileOpen} />
        <div className="admin-page animate-fade-in">
          {children}
        </div>
      </div>
    </div>
  );
};

export default AdminLayout;
