"use client";
import React, { useState } from 'react';
import Link from 'next/link';
import { usePathname } from 'next/navigation';
import '@/app/admin/css/custom.css';

const navItems = [
  { key: 'dashboard', title: 'Dashboard', icon: 'fas fa-th-large', path: '/admin/dashboard' },
  {
    key: 'products', title: 'Products', icon: 'fas fa-cube', path: '/admin/products',
    submenu: [
      { title: 'All Products', path: '/admin/products' },
      { title: 'Variants', path: '/admin/products/variants' },
      { title: 'Attributes', path: '/admin/products/attributes' },
      { title: 'Specifications', path: '/admin/products/specifications' },
      { title: 'Tags', path: '/admin/products/tags' },
    ],
  },
  { key: 'categories', title: 'Categories', icon: 'fas fa-folder', path: '/admin/categories' },
  { key: 'inventory', title: 'Inventory', icon: 'fas fa-boxes', path: '/admin/inventory' },
  { key: 'orders', title: 'Orders', icon: 'fas fa-shopping-bag', path: '/admin/orders' },
  { key: 'users', title: 'Customers', icon: 'fas fa-users', path: '/admin/users' },
  { key: 'media', title: 'Media', icon: 'fas fa-images', path: '/admin/media' },
  { key: 'reports', title: 'Reports', icon: 'fas fa-chart-bar', path: '/admin/reports' },
  { key: 'offers', title: 'Offers', icon: 'fas fa-percentage', path: '/admin/offers' },
  { key: 'pages', title: 'Pages', icon: 'fas fa-file-alt', path: '/admin/pages' },
  { key: 'reviews', title: 'Reviews', icon: 'fas fa-star', path: '/admin/reviews' },
  { key: 'testimonials', title: 'Testimonials', icon: 'fas fa-quote-right', path: '/admin/testimonials' },
  { key: 'shipping', title: 'Shipping', icon: 'fas fa-truck', path: '/admin/shipping' },
  { key: 'taxes', title: 'Taxes', icon: 'fas fa-receipt', path: '/admin/taxes' },
  {
    key: 'settings', title: 'Settings', icon: 'fas fa-cog', path: '/admin/settings',
    submenu: [
      { title: 'General', path: '/admin/settings' },
      { title: 'Payments', path: '/admin/settings/payments' },
      { title: 'Staff', path: '/admin/settings/staff' }
    ],
  },
  { key: 'notifications', title: 'Notifications', icon: 'fas fa-bell', path: '/admin/notifications' },
  { key: 'help', title: 'Support', icon: 'fas fa-life-ring', path: '/admin/help' },
];

const Sidebar = ({ mobileOpen, setMobileOpen, isExpanded, setIsExpanded }) => {
  const pathname = usePathname();
  const [openSubmenus, setOpenSubmenus] = useState({});

  const toggleSubmenu = (key) => {
    setOpenSubmenus(prev => ({ ...prev, [key]: !prev[key] }));
  };

  const isActive = (path) => pathname === path;
  const isSubmenuActive = (item) => {
    if (isActive(item.path)) return true;
    return item.submenu ? item.submenu.some(sub => isActive(sub.path)) : false;
  };

  return (
    <>
      <aside className={`admin-sidebar ${isExpanded ? 'expanded' : ''} ${mobileOpen ? 'mobile-show' : ''}`}
             style={{ transition: 'width 0.3s ease, transform 0.3s ease' }}>
        {/* Logo */}
        <div className="sidebar-logo">
          <div className="sidebar-logo-icon">
            <img src="/fylex_logo.png" alt="Fylex" />
          </div>
          <span className="sidebar-logo-text">Fylex</span>
          <button onClick={() => setMobileOpen(false)} className="ml-auto text-gray-400 hover:text-white md:hidden" style={{ border: 'none', background: 'none', cursor: 'pointer' }}>
            <i className="fas fa-times text-lg"></i>
          </button>
        </div>

        {/* Nav */}
        <nav className="sidebar-nav">
          {navItems.map((item) => {
            const hasSubmenu = !!item.submenu;
            const active = isSubmenuActive(item);
            const isOpen = openSubmenus[item.key] || (active && openSubmenus[item.key] === undefined);

            return (
              <div key={item.key}>
                {hasSubmenu ? (
                  <button onClick={() => toggleSubmenu(item.key)} className={`nav-link ${active ? 'active' : ''}`} style={{ width: '100%', border: 'none', background: 'none', font: 'inherit' }}>
                    <i className={item.icon}></i>
                    <span className="nav-link-text" style={{ flex: 1, textAlign: 'left' }}>{item.title}</span>
                    {isExpanded && <i className={`fas fa-chevron-down nav-link-text`} style={{ fontSize: 10, transform: isOpen ? 'rotate(180deg)' : 'none', transition: 'transform 0.2s' }}></i>}
                  </button>
                ) : (
                  <Link href={item.path} className={`nav-link ${active ? 'active' : ''}`} onClick={() => setMobileOpen(false)}>
                    <i className={item.icon}></i>
                    <span className="nav-link-text">{item.title}</span>
                  </Link>
                )}

                {hasSubmenu && isOpen && isExpanded && (
                  <div className="submenu">
                    {item.submenu.map((sub, idx) => (
                      <Link key={idx} href={sub.path} className={isActive(sub.path) ? 'active' : ''} onClick={() => setMobileOpen(false)}>
                        {sub.title}
                      </Link>
                    ))}
                  </div>
                )}
              </div>
            );
          })}
        </nav>

        {/* Footer */}
        <div className="sidebar-footer">
          <Link href="/admin/login" className="nav-link" style={{ marginBottom: 12, border: '1px solid rgba(239, 68, 68, 0.2)', background: 'rgba(239, 68, 68, 0.05)' }} onClick={() => setMobileOpen(false)}>
            <i className="fas fa-sign-out-alt" style={{ color: '#ef4444' }}></i>
            <span className="nav-link-text" style={{ color: '#ef4444', fontWeight: 600 }}>Logout</span>
          </Link>

          <button onClick={() => setIsExpanded(!isExpanded)} className="sidebar-toggle hidden md:flex">
            <i className={`fas fa-chevron-${isExpanded ? 'left' : 'right'}`}></i>
            {isExpanded && <span className="nav-link-text">Collapse</span>}
          </button>
        </div>
      </aside>

      {/* Mobile Overlay */}
      {mobileOpen && (
        <div onClick={() => setMobileOpen(false)}
             style={{ position: 'fixed', inset: 0, background: 'rgba(0,0,0,0.5)', zIndex: 30 }}
             className="md:hidden"></div>
      )}
    </>
  );
};

export default Sidebar;
